#include <stdio.h>
#include <stdlib.h>
#include <time.h>



int main(void)
{
    clock_t start, end;
    double cpu_time_used;
    int m=550;
    int r=450;
    int n=600;
    
    int A[m][r], B[r][n], C[m][n];
    
    start = clock();
    
    for (int i = 0; i <= m - 1; i++) {
        for (int j = 0; j <= r - 1; j++) {
            int a = rand();
            A[i][j]=a;
        }
    }
    for (int i = 0; i <= r - 1; i++) {
        for (int j = 0; j <= n - 1; j++) {
            int a = rand();
            B[i][j]=a;
        }
    }
    
    
    for (int i = 0; i <= m - 1; i++) {
        for (int j = 0; j <= n - 1; j++) {
            C[i][j] = 0;
        }
    }
    
    
    // algorithm with row in inner loop
    for (int i = 0; i <= m - 1; i++) {
        for (int j = 0; j <= n - 1; j++) {
            for (int k = 0; k <= r - 1; k++) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
    
    for (int i = 0; i <= m - 1; i++) {
        for (int j = 0; j <= n - 1; j++) {
            printf("%5d", C[i][j]);
            printf("--");
        }
        printf("\n");
    }
    end = clock();
    cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;
    printf("The time is %10.5f", cpu_time_used);
    
    printf("\n");
    return 0;
    
}

